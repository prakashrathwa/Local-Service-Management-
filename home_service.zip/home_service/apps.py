from django.apps import AppConfig


class HomeServiceConfig(AppConfig):
    name = 'home_service'
